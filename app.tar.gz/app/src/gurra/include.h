#ifndef GURRA_INCLUDE_H
#define GURRA_INCLUDE_H

#include "guiapplication.h"
#include "restconsumer.h"
#include "restconsumer2.h"
#include "restconsumer3.h"
#include "rest.h"
#include "restuploader.h"
#include "fileio.h"
#include "restmodel.h"

#endif // GURRA_INCLUDE_H
