#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QtQml>
#include <QFontDatabase>
#include "src/gurra/include.h"
#include "src/gurra/gu.h"


void registerTypes(){

    Gurra::Gu::registerTypes();
}

int main(int argc, char *argv[])
{
    registerTypes();

    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    Gurra::GuApplication app(argc, argv);

    QTranslator translator;
    translator.load("app_ar.qm", ":/assets/languages/");
    app.installTranslator(&translator);


    QQmlApplicationEngine engine;
    engine.addImportPath("qrc:/assets");

    Gurra::Gu gu;
    engine.rootContext()->setContextProperty("GuGui", &app);
    engine.rootContext()->setContextProperty("Gu", &gu);
    engine.load(QUrl(QLatin1String("qrc:/qml/main.qml")));

    return app.exec();
}
